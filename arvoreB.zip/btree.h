/* Estrutura de dados para árvores B
 */

#pragma once

#include <cassert>

// Declaração antecipada para classe amiga
template<typename T>
class ArvoreB;

// Declaração de um nó de árvore B contendo chaves e filhos privados.
// A manipulação terá que ocorrer por conta da classe ArvoreB.
template<typename T>
class NoB {
private:
	friend class ArvoreB<T>;
	T *chaves;
	NoB **filhos;
	int grau;

	// Declara a função de teste como uma amiga para que ela possa
	// inserir filhos na árvore
	template<typename U>
	friend ArvoreB<U> arvore_exemplo();
};

// Declaração da classe para árvores B
template<typename T>
class ArvoreB {
public:
	ArvoreB(int ordem);
private:
	NoB<T> *raiz;
	int ordem;

	// Cria um novo nó folha com um conjunto inicial de chaves
	NoB<T> *criar_no(int num_chaves=0, const T  *chaves=NULL);

	// Função amiga para gerar uma árvore B com altura 3 antes que as funções de inserção
	// sejam criadas. Use para os primeiros exercícios e para testes.
	template<typename U>
	friend ArvoreB<U> arvore_exemplo();
};


// Construtor da classe: define a ordem para toda a árvore e especifica
// a raiz como uma árvore vazia
// Pré-condições:
// - A ordem deve ser maior que 1
template<typename T>
ArvoreB<T>::ArvoreB(int ordem)
{
	assert(ordem > 1);
	this->ordem = ordem;
	this->raiz = NULL;
}


// Cria um novo nó folha com um conjunto inicial de chaves
// Pré-condições
// - O número de chaves não pode ser maior que o grau máximo da árvore
// - O número de chaves não deve ser menor que o grau mínimo da árvore (exceto para a raiz)
template<typename T>
NoB<T> *ArvoreB<T>::criar_no(int num_chaves, const T *chaves)
{
	int max_chaves = 2 * this->ordem - 1;
	assert(num_chaves < max_chaves);

	NoB<T> *novo = new NoB<T>;

	// Cria vetores para as chaves e os filhos (com uma posição a mais para promoções)
	novo->chaves = new T[max_chaves + 1];
	novo->filhos = new NoB<T>*[max_chaves + 2];

	// Insere as chaves no nó recém-criado
	for (int i = 0; i < num_chaves; i++) {
		novo->chaves[i] = chaves[i];
		novo->filhos[i] = NULL;
	}
	novo->filhos[num_chaves + 1] = NULL;

	// Define o grau da ordem. Se alguma chave foi especificada, então esta árvore possui um
	// grau; caso contrário, ela está vazia e seu grau é zero
	novo->grau = (num_chaves > 0 ? num_chaves + 1 : 0);

	return novo;
}
