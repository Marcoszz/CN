// Função que gera uma árvore de exemplo para testes

#pragma once

#include "btree.h"

// Função amiga da árvore B. Cria uma árvore de exemplo para testes. Utilize-a enquanto
// não houver terminado os exercícios de inserção de chaves em árvore B. Não crie outras
// funções amigas.
template<typename T>
ArvoreB<T> arvore_exemplo()
{
	// Cria um novo objeto de árvore B com ordem d=3.
	// Vamos recriar a árvore do slide 139 do Tópico 10
	ArvoreB<char> arvore(2);

	// Cria a raiz da árvore
	arvore.raiz = arvore.criar_no(1, "P");

	// Cria o nó contendo as chaves C, G e M
	NoB<char> *noCGM = arvore.criar_no(3, "CGM");

	// Cria o nó filho contendo as chaves A e B; insere como filho do nó CGM
	noCGM->filhos[0] = arvore.criar_no(2, "AB");

	// Cria o nó filho contendo as chaves D, E e F; insere como filho do nó CGM
	noCGM->filhos[1] = arvore.criar_no(3, "DEF");

	// Cria o nó filho contendo as chaves J, K e L; insere como filho do nó CGM
	noCGM->filhos[2] = arvore.criar_no(3, "JKL");

	// Cria o nó filho contendo as chaves N e O; insere como filho do nó CGM
	noCGM->filhos[3] = arvore.criar_no(2, "NO");

	// Insere o nó CGM como um filho da raiz
	arvore.raiz->filhos[0] = noCGM;

	// Cria o nó contendo as chaves T e X
	NoB<char> *noTX = arvore.criar_no(2, "TX");

	// Cria o nó filho contendo as chaves Q, R e S; insere como filho do nó TX
	noTX->filhos[0] = arvore.criar_no(3, "QRS");

	// Cria o nó filho contendo as chaves U e V; insere como filho do nó TX
	noTX->filhos[1] = arvore.criar_no(2, "UV");

	// Cria o nó filho contendo as chaves Y e Z; insere como filho do nó TX
	noTX->filhos[2] = arvore.criar_no(2, "YZ");

	// Insere o nó TX como um filho da raiz
	arvore.raiz->filhos[1] = noTX;

	// Retorna a árvore montada
	return arvore;
}
